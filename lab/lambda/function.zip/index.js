exports.handler = function (event, context, callback) {
  console.log("My First Lambda Function");
};
